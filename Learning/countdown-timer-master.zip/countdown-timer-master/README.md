# countdown-timer
A JQuery countdown timer by Mr. Winz. Get more video from www.youtube.com/c/WinzITSolutionz
